import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.math.BigDecimal;

import org.junit.Test;

import com.assignment.dto.CardTO;
import com.assignment.exception.APIException;

public class CardTest {

	@Test
	public void testCheckBalance() throws APIException {
		CardTO card = new CardTO(new BigDecimal("30.00"));
		BigDecimal result = card.checkBalance(new BigDecimal("2.50"));
		assertNotNull(result);
		assertEquals(new BigDecimal("30.00"), result);
	}

	@Test
	public void testRechageCard() throws APIException {
		CardTO card = new CardTO(new BigDecimal("30.00"));
		BigDecimal result = card.rechageCard(new BigDecimal("2.50"));
		assertNotNull(result);
		assertEquals(new BigDecimal("32.50"), result);
	}

	@Test
	public void testDeductTripAmount() throws APIException {
		CardTO card = new CardTO(new BigDecimal("30.00"));
		BigDecimal result = card.deductTripAmount(new BigDecimal("2.50"));
		assertNotNull(result);
		assertEquals(new BigDecimal("27.50"), result);
	}

}