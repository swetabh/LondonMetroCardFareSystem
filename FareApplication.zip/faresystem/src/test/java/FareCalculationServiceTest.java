import static com.assignment.implementation.FareCalculationService.calculateFinalBalance;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.math.BigDecimal;

import org.junit.Test;

import com.assignment.dto.CardTO;
import com.assignment.exception.APIException;
import com.assignment.types.StationType;
import com.assignment.types.TransportType;

public class FareCalculationServiceTest {

	@Test(expected = APIException.class)
	public void testCalculateFinalBalanceException() throws APIException {

		BigDecimal finalAmount = new BigDecimal("0.00");
		CardTO card = new CardTO(finalAmount);
		card.rechageCard(finalAmount); // Initial Recharge of 30.00

		// 1. Tube Holborn to Earl’s Court
		StationType source = StationType.HOLBORN;
		StationType destination = StationType.EARLSCOURT;
		TransportType transportType = TransportType.TUBE;

		calculateFinalBalance(card, source, destination, transportType);
	}

	@Test
	public void testCalculateTubeFinalBalance() throws APIException {

		BigDecimal finalAmount = new BigDecimal("0.00");
		CardTO card = new CardTO(finalAmount);
		card.rechageCard(new BigDecimal("30.00")); // Initial Recharge of 30.00

		// 1. Tube Holborn to Earl’s Court
		StationType source = StationType.HOLBORN;
		StationType destination = StationType.EARLSCOURT;
		TransportType transportType = TransportType.TUBE;

		finalAmount = calculateFinalBalance(card, source, destination, transportType);
		assertNotNull(finalAmount);
		assertEquals(new BigDecimal("27.50"), finalAmount);
	}

	@Test
	public void testCalculateBusFinalBalance() throws APIException {

		BigDecimal finalAmount = new BigDecimal("0.00");
		CardTO card = new CardTO(finalAmount);
		card.rechageCard(new BigDecimal("30.00")); // Initial Recharge of 30.00

		// 1. Bus Holborn to Earl’s Court
		StationType source = StationType.HOLBORN;
		StationType destination = StationType.EARLSCOURT;
		TransportType transportType = TransportType.BUS;

		finalAmount = calculateFinalBalance(card, source, destination, transportType);
		assertNotNull(finalAmount);
		assertEquals(new BigDecimal("28.20"), finalAmount);
	}
	
}