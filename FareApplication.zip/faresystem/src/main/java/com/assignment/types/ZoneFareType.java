package com.assignment.types;

import java.math.BigDecimal;

public enum ZoneFareType {

	INZONE1("1", new BigDecimal("2.50")), 
	ONEZONEOUTSIDEZONE1("2,3", new BigDecimal("2.00")),
	TWOZONESINCLUDEZONE1("1,2", new BigDecimal("3.00")), 
	TWOZONESEXCLUDEZONE1("2,3", new BigDecimal("2.25")),
	MORETHANTWOZONES("1,2,3", new BigDecimal("3.20")), 
	BUSJOURNEY("4", new BigDecimal("1.80"));

	private String zone;
	private BigDecimal fareAmount;

	private ZoneFareType(String zone, BigDecimal fareAmount) {
		this.zone = zone;
		this.fareAmount = fareAmount;
	}

	public String getZone() {
		return zone;
	}

	public BigDecimal getFareAmount() {
		return fareAmount;
	}

}