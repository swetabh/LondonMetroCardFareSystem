package com.assignment.types;

public enum StationType {

	HOLBORN("Holborn", "1"), 
	ALDGATE("Aldgate", "1"), 
	EARLSCOURT("Earl’s Court", "1,2"), 
	HAMMERSMITH("Hammersmith", "2"),
	ARSENAL("Arsenal", "2"), 
	WIMBLEDON("Wimbledon", "3"),
	CHELSEA("Chelsea", "4");

	private String description;
	private String zoneID;

	private StationType(String description, String zoneID) {
		this.description = description;
		this.zoneID = zoneID;
	}

	public String getDescription() {
		return description;
	}

	public String getZone() {
		return zoneID;
	}

}