package com.assignment.types;

public enum TransportType {

	TUBE("Tube"), BUS("Bus");

	private String transport;

	private TransportType(String zone) {
		this.transport = zone;
	}

	public String getTransportType() {
		return transport;
	}

}