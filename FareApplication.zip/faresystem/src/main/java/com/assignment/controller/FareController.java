package com.assignment.controller;

import static com.assignment.implementation.FareCalculationService.calculateFinalBalance;
import static org.slf4j.LoggerFactory.getLogger;

import java.io.IOException;
import java.math.BigDecimal;

import org.slf4j.Logger;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.assignment.dto.CardTO;
import com.assignment.exception.APIException;
import com.assignment.types.StationType;
import com.assignment.types.TransportType;

@RestController
@RequestMapping(path = { "/api/fare" })
public class FareController {

	private Logger log = getLogger(FareController.class);

	@GetMapping(path = "/calculateFare")
	public BigDecimal calculateFare() throws IOException, APIException {

		log.info("calculateFare api initiated");
		
		BigDecimal finalAmount = new BigDecimal("0.00");
		
		CardTO card = new CardTO(finalAmount);
		card.rechageCard(new BigDecimal("30.00")); // Initial Recharge of 30.00
		
		// 1. Tube Holborn to Earl’s Court
		StationType source = StationType.HOLBORN;
		StationType destination = StationType.EARLSCOURT;
		TransportType transportType = TransportType.TUBE;

		finalAmount = calculateFinalBalance(card, source, destination, transportType);
		System.out.println("Balance after Trip 1: " + finalAmount);
		
		
		// 2. 328 bus from Earl’s Court to Chelsea
		source = StationType.EARLSCOURT;
		destination = StationType.CHELSEA;
		transportType = TransportType.BUS;
		
		finalAmount = calculateFinalBalance(card, source, destination, transportType);
		System.out.println("Balance after Trip 2: " + finalAmount);
		
		// 3. Tube from Earl’s court to Hammersmith
		source = StationType.EARLSCOURT;
		destination = StationType.HAMMERSMITH;
		transportType = TransportType.TUBE;
		
		finalAmount = calculateFinalBalance(card, source, destination, transportType);
		System.out.println("Balance after Trip 1: " + finalAmount);
		return finalAmount;
	}

}