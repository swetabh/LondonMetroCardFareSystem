package com.assignment.implementation;

import static org.slf4j.LoggerFactory.getLogger;

import java.math.BigDecimal;

import org.slf4j.Logger;

import com.assignment.dto.CardTO;
import com.assignment.exception.APIException;
import com.assignment.types.StationType;
import com.assignment.types.TransportType;
import com.assignment.types.ZoneFareType;

public class FareCalculationService {

	private static final Logger log = getLogger(FareCalculationService.class);
	private static final String BUS = "Bus";

	/***
	 * Method to calculate the balance after a trip
	 * @param card
	 * @param source
	 * @param destination
	 * @param transportType
	 * @return
	 * @throws APIException
	 */
	public static BigDecimal calculateFinalBalance(CardTO card, StationType source, StationType destination,
			TransportType transportType) throws APIException {

		try {
			getFinalBalanceAmount(card, source, destination, transportType);
		} catch (Exception e) {
			log.error("Exception occurred while calculating the final amount {}", e.getMessage(), e);
			throw new APIException("Exception occurred while calculating the final amount", e);
		}
		return card.getBalanceAmount();
	}

	private static BigDecimal getFinalBalanceAmount(CardTO card, StationType source, StationType destination,
			TransportType transportType) throws APIException {

		BigDecimal tripAmount = calculateTripAmount(source, destination, transportType);
		card.setBalanceAmount(card.deductTripAmount(tripAmount));
		return card.getBalanceAmount();
	}

	private static BigDecimal calculateTripAmount(StationType source, StationType destination,
			TransportType transportType) {

		BigDecimal tripAmount = new BigDecimal("0.00");
		if (BUS.equalsIgnoreCase(transportType.getTransportType())) {
			tripAmount = ZoneFareType.BUSJOURNEY.getFareAmount();
		} else {
			String zone1 = source.getZone();
			String zone2 = destination.getZone();
			if (zone1.contains("1") && zone2.contains("1")) {
				tripAmount = ZoneFareType.INZONE1.getFareAmount();
			} else if (zone1.contains("2") && zone2.contains("2")
					|| zone2.contains("3") && zone1.contains("3")) {
				tripAmount = ZoneFareType.ONEZONEOUTSIDEZONE1.getFareAmount();
			} else if (zone1.contains("1") && zone2.contains("2")
					|| zone2.contains("1") && zone1.contains("2")) {
				tripAmount = ZoneFareType.TWOZONESINCLUDEZONE1.getFareAmount();
			} else if (zone1.contains("2") && zone2.contains("3")
					|| zone2.contains("2") && zone1.contains("3")) {
				tripAmount = ZoneFareType.TWOZONESEXCLUDEZONE1.getFareAmount();
			}
		}
		return tripAmount;
	}

}