package com.assignment.dto;

import java.math.BigDecimal;

import com.assignment.exception.APIException;

public class CardTO {

	private BigDecimal balanceAmount;

	public CardTO(BigDecimal balanceAmount) {
		super();
		this.balanceAmount = balanceAmount;
	}

	public BigDecimal getBalanceAmount() {
		return balanceAmount;
	}

	public void setBalanceAmount(BigDecimal balanceAmount) {
		this.balanceAmount = balanceAmount;
	}

	public BigDecimal checkBalance(BigDecimal fare) throws APIException {

		if (balanceAmount.compareTo(fare) < 0) {
			throw new APIException("Balance is low. Please recharge the card");
		}
		return balanceAmount;
	}

	public BigDecimal rechageCard(BigDecimal rechargeAount) {

		balanceAmount = balanceAmount.add(rechargeAount);
		return balanceAmount;
	}

	public BigDecimal deductTripAmount(BigDecimal fareAmount) throws APIException {

		checkBalance(fareAmount);
		return balanceAmount.subtract(fareAmount);
	}

}