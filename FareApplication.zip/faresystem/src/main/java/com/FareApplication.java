package com;

import static org.springframework.boot.SpringApplication.run;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FareApplication {

	public static void main(String[] args) {
		run(FareApplication.class, args);
	}

}