This project is a simple Java Based application applying some Business conditions which as per the following logic:

1. When the user passes through the inward barrier at the station, their oyster card is charged
the maximum fare.
2. When they pass out of the barrier at the exit station, the fare is calculated and the maximum
fare transaction removed and replaced with the real transaction (in this way, if the user
doesn’t swipe out, they are charged the maximum fare).
3. All bus journeys are charged at the same price.
4. The system should favour the customer where more than one fare is possible for a given
journey. E.g. Holburn to Earl’s Court is charged at £2.50.

Assumptions :
1. Any bus journey costs flat 1.80 Euro
2. The maximum possible fare is 3.20 Euro


Note: In order to run the project, kindly download the source code and run the code as mvn clean install 
 
## Requirements

For building and running the application you need:

- [JDK 1.8](http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)
- [Maven 3](https://maven.apache.org)

## Approach Discussion
It's a standalone application consist of all Possible test cases. Following are the approach has been taken to address this assignment

1. Designed in a way that each fare policy can be tested independently.

## How to Run

Run the FareApplication class and call the rest GET api "http://localhost:8080/api/fare/calculateFare"

## How to get Coverage
```shell
mvn clean install
```
it will generate coverage reports in faresystem\target\site\jacoco
Open index.html

